# Portfolio — Aymane Chadni

Portfolio bilingue (FR/EN) compatible GitHub Pages, aligné avec le CV IA & Data Science.

## Publication GitHub Pages

1. Copier le contenu à la racine du dépôt `aymanechadni.github.io`.
2. GitHub → **Settings** → **Pages**.
3. Source : **Deploy from a branch**.
4. Branche : `main`, dossier : `/ (root)`.
5. Enregistrer.

Le site sera publié sur : `https://aymanechadni.github.io/`.

## Fichiers principaux

- `index.html` : structure, SEO et accessibilité.
- `style.css` : design responsive.
- `app.js` : contenu FR/EN, animations, navigation active et interactions.
- `assets/portrait.png` : portrait.
- `assets/cv-fr.pdf` : CV final téléchargeable.

## Liens intégrés

- LinkedIn : `https://www.linkedin.com/in/aymane-chadni-926053337/`
- GitHub : `https://github.com/aymanechadni`
