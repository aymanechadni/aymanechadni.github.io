const LINKS = {
  email: 'Aymane.Chadni@emsi-edu.ma',
  linkedin: 'https://www.linkedin.com/in/aymane-chadni-926053337/',
  github: 'https://github.com/aymanechadni',
  cv: 'assets/cv-fr.pdf'
};

const content = {
  fr: {
    navAbout:'Profil', navExperience:'Expérience', navProjects:'Projets', navSkills:'Compétences', navContact:'Contact', top:'Retour en haut ↑',
    availability:'Disponible pour un stage PFE · Perspective de pré-embauche',
    role:'Étudiant ingénieur · Intelligence Artificielle & Data Science',
    headline:'Transformer les <em>données</em><br>en solutions utiles.',
    intro:'Étudiant ingénieur en 5ᵉ année à l’EMSI, spécialisé en Intelligence Artificielle et Data Science. Je développe des solutions mêlant Machine Learning, Deep Learning, Big Data et développement logiciel.',
    projectsCta:'Voir mes projets', cvCta:'Télécharger mon CV', linkedinCta:'LinkedIn', githubCta:'GitHub', location:'Tanger, Maroc · EMSI',
    stats:[['5ᵉ','année ingénieur'],['2','expériences'],['2','projets IA/Data'],['2027','diplôme prévu']],
    aboutEyebrow:'01 / Profil', aboutTitle:'IA, Data et ingénierie logicielle.', aboutText:'Mon profil combine Intelligence Artificielle, Data Engineering, Business Intelligence et développement full-stack. Je recherche un stage PFE pour contribuer à des projets IA/Data à forte valeur ajoutée, idéalement avec une perspective de pré-embauche.',
    experienceEyebrow:'02 / Expérience professionnelle', experienceTitle:'Expérience en entreprise.', experienceIntro:'Des projets appliqués à la supervision réseau intelligente et au développement web.',
    experiences:[
      {date:'JUILLET — SEPTEMBRE 2026',type:'Stage d’ingénierie',company:'BBRS Consulting',place:'Tanger',title:'DNOC IA Platform — Supervision réseau intelligente',description:'Développement d’une plateforme de supervision, d’analyse et de diagnostic des infrastructures réseau Aruba, avec collecte et normalisation des données, assistant IA RAG et interface de monitoring.',tags:['Python','FastAPI','PostgreSQL','MinIO','React','TypeScript','Ollama','RAG','Docker','Kafka','Spark','Airflow']},
      {date:'JUILLET — SEPTEMBRE 2026',type:'Stage d’application',company:'Smart Automation Technologies',place:'Tanger',title:'Application web de gestion de données footballistiques',description:'Développement d’une application web de consultation et de gestion des clubs, matchs, joueurs et classements.',tags:['Angular 16','TypeScript','HTML5','CSS3','REST API','UML','Git/GitLab','Jira','Scrum']}
    ],
    projectEyebrow:'03 / Projets académiques', projectTitle:'Projets IA & Data.', projectIntro:'Deux projets académiques qui illustrent mon travail en Data Engineering, Machine Learning, BI et Deep Learning.', details:'Voir les détails',
    projects:[
      {date:'MARS — JUIN 2026',category:'PROJET DE FIN D’ANNÉE',title:'SmartCommerce AI Platform',description:'Plateforme e-commerce intelligente intégrant Data Engineering, Machine Learning, Business Intelligence et systèmes multi-agents.',flow:['Ingestion','Data & IA','Décision'],label:'DATA / COMMERCE',tags:['Python','PySpark','Airbyte','MinIO','Kafka','Airflow','XGBoost','ALS','SBERT','FAISS','Power BI','FastAPI','React'],points:['Pipeline Big Data et Data Warehouses.','Modules IA : recommandation, détection de fraude, churn et recherche sémantique.','Dashboards Power BI et backend FastAPI avec interface React/Vite.']},
      {date:'MARS — MAI 2025',category:'PROJET DE FIN D’ANNÉE',title:'SANTE — Plateforme Web Médicale Intelligente',description:'Plateforme médicale intégrant téléconsultation, prise de rendez-vous, assistant IA et suivi patient, avec détection de maladies cutanées à partir d’images.',flow:['Image','CNN','Diagnostic'],label:'AI / HEALTH',tags:['Python','Flask','TensorFlow','Keras','CNN','PHP','MySQL','JavaScript','REST API','UML'],points:['Détection de maladies cutanées à partir d’images avec CNN.','Intégration du modèle via une API Flask.','Gestion des utilisateurs, rendez-vous et suivi patient.']}
    ],
    skillsEyebrow:'04 / Compétences techniques', skillsTitle:'Un profil technique transversal.', skillsIntro:'Les technologies et méthodes principales de mon CV.',
    skills:[
      ['IA & Data Science','Machine Learning · Deep Learning · CNN · NLP · Computer Vision · Generative AI · XGBoost · Autoencoder · ALS · SBERT · FAISS · TensorFlow · Keras · Scikit-learn · Systèmes multi-agents'],
      ['Data Engineering & Big Data','Apache Spark · PySpark · Kafka · Hadoop · Airflow · Airbyte · MinIO · ETL · Data Lakes · Data Warehousing · Data Analytics'],
      ['Développement','Python · Java · C/C++ · PHP · JavaScript · TypeScript · FastAPI · Flask · Node.js · Express.js · React · Angular · REST API'],
      ['Bases de données','PostgreSQL · MySQL · Oracle · SQL Server · MongoDB · Redis · Neo4j · Cassandra'],
      ['Business Intelligence','Power BI · SQL · Data Warehouse · Reporting'],
      ['Cloud, DevOps & Architecture','Docker · Git · GitHub · GitLab · Linux · CI/CD · Jira · UML · Merise · MVC · Microservices · Agile/Scrum']
    ],
    educationTitle:'Formation', education:[['2022 — 2027','Cycle Ingénieur — Informatique & Réseaux','EMSI Tanger · Spécialisation IA & Data Science'],['2021 — 2022','Baccalauréat International — Sciences Physiques','Yanboe Annour 2 · Option Français']],
    certTitle:'Certifications', certs:[['Oracle Database 19c Administrator Professional','Oracle · En cours'],['Introduction to Machine Learning','Duke University']],
    engagementTitle:'Engagement', engagement:'Membre du Club InnovaxTech — EMSI : participation aux activités et initiatives autour de l’innovation, de l’IA et des nouvelles technologies.',
    languagesTitle:'Langues & qualités', languages:'Français : intermédiaire · Anglais : intermédiaire', qualities:'Communication · Esprit d’équipe · Rigueur',
    contactEyebrow:'05 / Contact', contactTitle:'Construisons quelque chose <em>d’utile.</em>', contactIntro:'Ouvert aux opportunités de stage PFE en IA, Data Science, Data Engineering et domaines connexes.', write:'M’écrire', viewLinkedIn:'Voir LinkedIn ↗', viewGithub:'Voir GitHub ↗'
  },
  en: {
    navAbout:'About', navExperience:'Experience', navProjects:'Projects', navSkills:'Skills', navContact:'Contact', top:'Back to top ↑',
    availability:'Open to a final-year internship · Pre-hire opportunity welcome',
    role:'Engineering student · Artificial Intelligence & Data Science',
    headline:'Turning <em>data</em><br>into useful solutions.',
    intro:'Fifth-year engineering student at EMSI, specializing in Artificial Intelligence and Data Science. I build solutions combining Machine Learning, Deep Learning, Big Data and software development.',
    projectsCta:'View my projects', cvCta:'Download my CV', linkedinCta:'LinkedIn', githubCta:'GitHub', location:'Tangier, Morocco · EMSI',
    stats:[['5th','engineering year'],['2','internships'],['2','AI/Data projects'],['2027','expected graduation']],
    aboutEyebrow:'01 / About', aboutTitle:'AI, Data and software engineering.', aboutText:'My profile combines Artificial Intelligence, Data Engineering, Business Intelligence and full-stack development. I am looking for a final-year internship where I can contribute to high-impact AI/Data projects, ideally with a pre-hire opportunity.',
    experienceEyebrow:'02 / Professional experience', experienceTitle:'Industry experience.', experienceIntro:'Applied projects in intelligent network monitoring and web development.',
    experiences:[
      {date:'JULY — SEPTEMBER 2026',type:'Engineering internship',company:'BBRS Consulting',place:'Tangier',title:'DNOC IA Platform — Intelligent network monitoring',description:'Development of a platform for monitoring, analyzing and diagnosing Aruba network infrastructures, including data collection and normalization, a RAG AI assistant and a monitoring interface.',tags:['Python','FastAPI','PostgreSQL','MinIO','React','TypeScript','Ollama','RAG','Docker','Kafka','Spark','Airflow']},
      {date:'JULY — SEPTEMBER 2026',type:'Application internship',company:'Smart Automation Technologies',place:'Tangier',title:'Football data management web application',description:'Development of a web application for viewing and managing clubs, matches, players and rankings.',tags:['Angular 16','TypeScript','HTML5','CSS3','REST API','UML','Git/GitLab','Jira','Scrum']}
    ],
    projectEyebrow:'03 / Academic projects', projectTitle:'AI & Data projects.', projectIntro:'Two academic projects showcasing Data Engineering, Machine Learning, BI and Deep Learning.', details:'View details',
    projects:[
      {date:'MARCH — JUNE 2026',category:'END-OF-YEAR PROJECT',title:'SmartCommerce AI Platform',description:'An intelligent e-commerce platform combining Data Engineering, Machine Learning, Business Intelligence and multi-agent systems.',flow:['Ingestion','Data & AI','Decision'],label:'DATA / COMMERCE',tags:['Python','PySpark','Airbyte','MinIO','Kafka','Airflow','XGBoost','ALS','SBERT','FAISS','Power BI','FastAPI','React'],points:['Big Data pipeline and Data Warehouses.','AI modules for recommendation, fraud detection, churn and semantic search.','Power BI dashboards and a FastAPI backend with a React/Vite interface.']},
      {date:'MARCH — MAY 2025',category:'END-OF-YEAR PROJECT',title:'SANTE — Intelligent Medical Web Platform',description:'Medical platform integrating teleconsultation, appointment booking, an AI assistant and patient follow-up, with skin disease detection from images.',flow:['Image','CNN','Diagnosis'],label:'AI / HEALTH',tags:['Python','Flask','TensorFlow','Keras','CNN','PHP','MySQL','JavaScript','REST API','UML'],points:['Skin disease detection from images using a CNN.','Model integration through a Flask API.','User, appointment and patient follow-up management.']}
    ],
    skillsEyebrow:'04 / Technical skills', skillsTitle:'A cross-functional technical profile.', skillsIntro:'The main technologies and methods listed on my CV.',
    skills:[
      ['AI & Data Science','Machine Learning · Deep Learning · CNN · NLP · Computer Vision · Generative AI · XGBoost · Autoencoder · ALS · SBERT · FAISS · TensorFlow · Keras · Scikit-learn · Multi-agent systems'],
      ['Data Engineering & Big Data','Apache Spark · PySpark · Kafka · Hadoop · Airflow · Airbyte · MinIO · ETL · Data Lakes · Data Warehousing · Data Analytics'],
      ['Development','Python · Java · C/C++ · PHP · JavaScript · TypeScript · FastAPI · Flask · Node.js · Express.js · React · Angular · REST API'],
      ['Databases','PostgreSQL · MySQL · Oracle · SQL Server · MongoDB · Redis · Neo4j · Cassandra'],
      ['Business Intelligence','Power BI · SQL · Data Warehouse · Reporting'],
      ['Cloud, DevOps & Architecture','Docker · Git · GitHub · GitLab · Linux · CI/CD · Jira · UML · Merise · MVC · Microservices · Agile/Scrum']
    ],
    educationTitle:'Education', education:[['2022 — 2027','Engineering Degree — Computer Science & Networks','EMSI Tangier · AI & Data Science specialization'],['2021 — 2022','International Baccalaureate — Physical Sciences','Yanboe Annour 2 · French option']],
    certTitle:'Certifications', certs:[['Oracle Database 19c Administrator Professional','Oracle · In progress'],['Introduction to Machine Learning','Duke University']],
    engagementTitle:'Engagement', engagement:'Member of InnovaxTech Club — EMSI, taking part in activities and initiatives around innovation, AI and emerging technologies.',
    languagesTitle:'Languages & qualities', languages:'French: intermediate · English: intermediate', qualities:'Communication · Teamwork · Rigor',
    contactEyebrow:'05 / Contact', contactTitle:'Let’s build something <em>useful.</em>', contactIntro:'Open to final-year internship opportunities in AI, Data Science, Data Engineering and related fields.', write:'Email me', viewLinkedIn:'View LinkedIn ↗', viewGithub:'View GitHub ↗'
  }
};

const tags = values => `<div class="tags">${values.map(v=>`<span>${v}</span>`).join('')}</div>`;
const heading = (eyebrow,title,intro='') => `<div class="section-heading reveal"><div><p class="eyebrow">${eyebrow}</p><h2>${title}</h2></div>${intro?`<p>${intro}</p>`:''}</div>`;

function render(lang){
  const t = content[lang];
  document.documentElement.lang = lang;
  document.title = `Aymane Chadni — ${lang==='fr'?'IA':'AI'} & Data Science`;
  document.querySelectorAll('[data-text]').forEach(el => el.textContent = t[el.dataset.text]);
  document.querySelectorAll('[data-lang]').forEach(el => el.setAttribute('aria-pressed', String(el.dataset.lang === lang)));

  document.getElementById('main').innerHTML = `
    <section class="hero" id="about">
      <div class="hero-copy reveal">
        <div class="availability"><span></span>${t.availability}</div>
        <p class="eyebrow">${t.role}</p>
        <h1>${t.headline}</h1>
        <p class="intro">${t.intro}</p>
        <div class="actions">
          <a class="button primary" href="#projects">${t.projectsCta}<span>↘</span></a>
          <a class="button" href="${LINKS.cv}" download="Aymane-Chadni-CV.pdf">${t.cvCta}<span>↓</span></a>
        </div>
        <div class="social-inline">
          <a href="${LINKS.linkedin}" target="_blank" rel="noopener noreferrer">${t.linkedinCta} ↗</a>
          <a href="${LINKS.github}" target="_blank" rel="noopener noreferrer">${t.githubCta} ↗</a>
        </div>
        <p class="location">${t.location}</p>
      </div>
      <div class="portrait-card reveal">
        <div class="card-top"><span>PORTFOLIO / AC</span><span>AI · DATA · SOFTWARE</span></div>
        <div class="portrait-wrap"><img class="portrait" src="assets/portrait.png" width="377" height="377" alt="Portrait d’Aymane Chadni"></div>
        <div class="card-bottom"><div><strong>Aymane Chadni</strong><small>IA & Data Science</small></div><span class="badge">PFE 2026–2027</span></div>
      </div>
    </section>

    <section class="stats-strip">${t.stats.map(s=>`<div class="stat reveal"><strong>${s[0]}</strong><span>${s[1]}</span></div>`).join('')}</section>

    <section class="content about-section">
      ${heading(t.aboutEyebrow,t.aboutTitle)}
      <p class="about-copy reveal">${t.aboutText}</p>
    </section>

    <section class="content alt-section" id="experience">
      ${heading(t.experienceEyebrow,t.experienceTitle,t.experienceIntro)}
      <div class="experience-list">${t.experiences.map((e,i)=>`<article class="experience-card reveal"><div class="experience-meta"><span>0${i+1}</span><time>${e.date}</time></div><div><p class="type">${e.type}</p><h3>${e.company} <span>— ${e.place}</span></h3><h4>${e.title}</h4><p>${e.description}</p>${tags(e.tags)}</div></article>`).join('')}</div>
    </section>

    <section class="content" id="projects">
      ${heading(t.projectEyebrow,t.projectTitle,t.projectIntro)}
      <div class="project-grid">${t.projects.map((p,i)=>`<article class="project reveal"><div class="project-visual"><div class="visual-label"><span>${p.label}</span><span>0${i+1}</span></div><div class="flow">${p.flow.map((f,n)=>`${n?'<i>→</i>':''}<span>${f}</span>`).join('')}</div></div><div class="project-body"><span class="meta">${p.date} · ${p.category}</span><h3>${p.title}</h3><p>${p.description}</p>${tags(p.tags)}<details><summary>${t.details}</summary><ul>${p.points.map(pt=>`<li>${pt}</li>`).join('')}</ul></details></div></article>`).join('')}</div>
    </section>

    <section class="content alt-section" id="skills">
      ${heading(t.skillsEyebrow,t.skillsTitle,t.skillsIntro)}
      <div class="skill-grid">${t.skills.map((s,i)=>`<article class="skill reveal"><span class="number">0${i+1}</span><h3>${s[0]}</h3><p>${s[1]}</p></article>`).join('')}</div>
      <div class="extras">
        <div class="extra-card reveal"><h3>${t.educationTitle}</h3>${t.education.map(e=>`<div class="info-row"><time>${e[0]}</time><div><strong>${e[1]}</strong><p>${e[2]}</p></div></div>`).join('')}</div>
        <div class="extra-card reveal"><h3>${t.certTitle}</h3>${t.certs.map(c=>`<div class="cert"><strong>${c[0]}</strong><p>${c[1]}</p></div>`).join('')}</div>
        <div class="extra-card reveal"><h3>${t.engagementTitle}</h3><p>${t.engagement}</p><h3 class="subheading">${t.languagesTitle}</h3><p>${t.languages}</p><p>${t.qualities}</p></div>
      </div>
    </section>

    <section class="contact reveal" id="contact">
      <div><p class="eyebrow">${t.contactEyebrow}</p><h2>${t.contactTitle}</h2><p>${t.contactIntro}</p></div>
      <div class="contact-links">
        <a class="email" href="mailto:${LINKS.email}">${LINKS.email}</a>
        <a class="button accent" href="mailto:${LINKS.email}">${t.write}<span>↗</span></a>
        <a class="social" href="${LINKS.linkedin}" target="_blank" rel="noopener noreferrer">${t.viewLinkedIn}</a>
        <a class="social" href="${LINKS.github}" target="_blank" rel="noopener noreferrer">${t.viewGithub}</a>
      </div>
    </section>`;

  initReveal();
  initActiveNav();
}

function initReveal(){
  const items = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver(entries => entries.forEach(entry => {
    if(entry.isIntersecting){ entry.target.classList.add('visible'); io.unobserve(entry.target); }
  }), {threshold:.12});
  items.forEach(el => io.observe(el));
}

function initActiveNav(){
  const sections = [...document.querySelectorAll('main section[id]')];
  const links = [...document.querySelectorAll('#mainNav a')];
  const io = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        links.forEach(a => a.classList.toggle('active', a.getAttribute('href') === `#${entry.target.id}`));
      }
    });
  }, {rootMargin:'-38% 0px -56%'});
  sections.forEach(section => io.observe(section));
}

let lang = 'fr';
try { if(localStorage.getItem('portfolio-language') === 'en') lang = 'en'; } catch {}
render(lang);

document.querySelectorAll('[data-lang]').forEach(button => button.addEventListener('click', () => {
  lang = button.dataset.lang; render(lang);
  try { localStorage.setItem('portfolio-language', lang); } catch {}
}));

document.getElementById('year').textContent = new Date().getFullYear();

const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');
menuToggle.addEventListener('click', () => {
  const open = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
mainNav.addEventListener('click', e => {
  if(e.target.closest('a')){ mainNav.classList.remove('open'); menuToggle.setAttribute('aria-expanded','false'); }
});

window.addEventListener('scroll', () => {
  const max = document.documentElement.scrollHeight - innerHeight;
  document.getElementById('scrollBar').style.width = `${max > 0 ? (scrollY/max)*100 : 0}%`;
}, {passive:true});
